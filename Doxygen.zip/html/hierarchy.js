var hierarchy =
[
    [ "AbsPName", "class_abs_p_name.html", [
      [ "PName", "class_p_name.html", null ]
    ] ],
    [ "AbsPScore", "class_abs_p_score.html", [
      [ "PScore", "class_p_score.html", null ]
    ] ],
    [ "BaseBoard", "class_base_board.html", [
      [ "PlayerBoard", "class_player_board.html", null ]
    ] ],
    [ "Game", "class_game.html", null ],
    [ "Game::OutofRange", "class_game_1_1_outof_range.html", null ],
    [ "Person< TN, TS >", "class_person.html", null ],
    [ "Player", "class_player.html", null ]
];