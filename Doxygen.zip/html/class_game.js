var class_game =
[
    [ "OutofRange", "class_game_1_1_outof_range.html", null ],
    [ "Game", "class_game.html#ad59df6562a58a614fda24622d3715b65", null ],
    [ "Battlecheck1", "class_game.html#a5b015c7071e9b784445525ea6e748b0c", null ],
    [ "Battlecheck2", "class_game.html#a460725dd0162114761cc900f8ea7024a", null ],
    [ "Carriercheck1", "class_game.html#ae606f59f6c181bcc3bf9d645515df4ac", null ],
    [ "Carriercheck2", "class_game.html#a1634c0a6c6b48c490c34b1dc133b9590", null ],
    [ "Destroycheck1", "class_game.html#adb51ae8bb6fcd0cf15924a9d2900e20a", null ],
    [ "Destroycheck2", "class_game.html#afa20c19095f5166a3b3484e19d2e389e", null ],
    [ "gameguess1", "class_game.html#afc83f4f5c59e23356925960c79502361", null ],
    [ "gameguess2", "class_game.html#a32a9fb49cbac61d31f8b1978adf3b944", null ],
    [ "playgame", "class_game.html#a35bbac189f7036e4d8fd38b0639339f7", null ],
    [ "resultCheck1", "class_game.html#a76a9af71973828b4913f10628b2a87b8", null ],
    [ "resultCheck2", "class_game.html#a148bc722f76cbef464fac38fee319cf3", null ],
    [ "Submarinecheck1", "class_game.html#a3e52b41111cb2496c82b8c0c883a43a5", null ],
    [ "Submarinecheck2", "class_game.html#ae93eafb59a9f969e71828051233ffcf5", null ],
    [ "guessC", "class_game.html#a56749942a2c1999e7d9bae832349b628", null ],
    [ "guessR", "class_game.html#a6fc5ec3d8fb62b70a9639a2ae14733b2", null ],
    [ "playerboard", "class_game.html#a49186eea328cf43088ff4d9547492c85", null ]
];