var files_dup =
[
    [ "build", "dir_4fef79e7177ba769987a8da36c892c5f.html", "dir_4fef79e7177ba769987a8da36c892c5f" ],
    [ "nbproject", "dir_2c333aeabd346f33518e235a93545ab3.html", "dir_2c333aeabd346f33518e235a93545ab3" ],
    [ ".dep.inc", "_8dep_8inc.html", null ],
    [ "board.cpp", "board_8cpp.html", null ],
    [ "board.h", "board_8h.html", "board_8h" ],
    [ "game.cpp", "game_8cpp.html", null ],
    [ "game.h", "game_8h.html", "game_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "player.cpp", "player_8cpp.html", "player_8cpp" ],
    [ "player.h", "player_8h.html", "player_8h" ],
    [ "template.h", "template_8h.html", "template_8h" ]
];