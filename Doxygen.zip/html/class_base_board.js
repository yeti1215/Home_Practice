var class_base_board =
[
    [ "BaseBoard", "class_base_board.html#a2f1f1b430ab82f9b689d7089f8ccb7ab", null ],
    [ "~BaseBoard", "class_base_board.html#aa48ad0c4977afb55c0759d4422b9dd7a", null ],
    [ "displayBoard", "class_base_board.html#a2447a703904cc9352af2eb0dc1531ca2", null ],
    [ "col", "class_base_board.html#a3ed1a0462a528d31ab024017ef8f78ca", null ],
    [ "row", "class_base_board.html#af07c9dd3f398cb159bf299654b6c5a44", null ]
];