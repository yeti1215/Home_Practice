var class_person =
[
    [ "Person", "class_person.html#a31da940c7eddb2fa2c118f6cc734d661", null ],
    [ "showPerson", "class_person.html#a44ddc57bb6eb0763f08be22ef825016b", null ],
    [ "Name", "class_person.html#a7a072687508bca144ed4a60f64849713", null ],
    [ "Score", "class_person.html#a3ac8ebb5ff20f5605216bfdf02799bcf", null ]
];