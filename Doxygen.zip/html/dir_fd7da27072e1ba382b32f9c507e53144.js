var dir_fd7da27072e1ba382b32f9c507e53144 =
[
    [ "Cygwin-Windows", "dir_5aa0f545e3a098f50edcb27c1cb11f25.html", "dir_5aa0f545e3a098f50edcb27c1cb11f25" ],
    [ "MinGW-Windows", "dir_e63cc7c69855e9c38c9b8f596fc63cfa.html", "dir_e63cc7c69855e9c38c9b8f596fc63cfa" ]
];