var annotated_dup =
[
    [ "AbsPName", "class_abs_p_name.html", "class_abs_p_name" ],
    [ "AbsPScore", "class_abs_p_score.html", "class_abs_p_score" ],
    [ "BaseBoard", "class_base_board.html", "class_base_board" ],
    [ "Game", "class_game.html", "class_game" ],
    [ "Person", "class_person.html", "class_person" ],
    [ "Player", "class_player.html", "class_player" ],
    [ "PlayerBoard", "class_player_board.html", "class_player_board" ],
    [ "PName", "class_p_name.html", "class_p_name" ],
    [ "PScore", "class_p_score.html", "class_p_score" ]
];