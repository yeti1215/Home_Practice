var player_8h =
[
    [ "AbsPName", "class_abs_p_name.html", "class_abs_p_name" ],
    [ "AbsPScore", "class_abs_p_score.html", "class_abs_p_score" ],
    [ "Player", "class_player.html", "class_player" ],
    [ "PName", "class_p_name.html", "class_p_name" ],
    [ "PScore", "class_p_score.html", "class_p_score" ],
    [ "PLAYER_H", "player_8h.html#aa3fab1fddd7bdec7c2d0867fb8aaad64", null ]
];