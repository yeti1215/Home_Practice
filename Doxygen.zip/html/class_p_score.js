var class_p_score =
[
    [ "operator++", "class_p_score.html#af5d68c68c89a12aa19e94a74e9085f2e", null ]
];