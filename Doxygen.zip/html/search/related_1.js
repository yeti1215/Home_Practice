var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_player.html#a3c8267502d083e97914219d885aaa67f',1,'Player']]]
];
