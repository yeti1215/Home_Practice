var searchData=
[
  ['guessc_0',['guessC',['../class_game.html#a56749942a2c1999e7d9bae832349b628',1,'Game']]],
  ['guessr_1',['guessR',['../class_game.html#a6fc5ec3d8fb62b70a9639a2ae14733b2',1,'Game']]]
];
