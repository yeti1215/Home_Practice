var searchData=
[
  ['carriercheck1_0',['Carriercheck1',['../class_game.html#ae606f59f6c181bcc3bf9d645515df4ac',1,'Game']]],
  ['carriercheck2_1',['Carriercheck2',['../class_game.html#a1634c0a6c6b48c490c34b1dc133b9590',1,'Game']]]
];
