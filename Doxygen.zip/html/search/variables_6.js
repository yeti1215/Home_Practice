var searchData=
[
  ['row_0',['row',['../class_base_board.html#af07c9dd3f398cb159bf299654b6c5a44',1,'BaseBoard']]]
];
