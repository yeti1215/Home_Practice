var searchData=
[
  ['person_0',['Person',['../class_person.html',1,'']]],
  ['player_1',['Player',['../class_player.html',1,'']]],
  ['playerboard_2',['PlayerBoard',['../class_player_board.html',1,'']]],
  ['pname_3',['PName',['../class_p_name.html',1,'']]],
  ['pscore_4',['PScore',['../class_p_score.html',1,'']]]
];
