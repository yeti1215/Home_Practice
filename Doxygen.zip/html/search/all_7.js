var searchData=
[
  ['name_0',['Name',['../class_person.html#a7a072687508bca144ed4a60f64849713',1,'Person']]]
];
