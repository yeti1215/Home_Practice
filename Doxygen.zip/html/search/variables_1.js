var searchData=
[
  ['col_0',['col',['../class_base_board.html#a3ed1a0462a528d31ab024017ef8f78ca',1,'BaseBoard']]],
  ['count_1',['count',['../class_player_board.html#a9ff6bc6ed89406f735680239123448ae',1,'PlayerBoard']]]
];
