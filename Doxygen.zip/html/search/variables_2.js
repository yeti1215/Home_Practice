var searchData=
[
  ['direct_0',['direct',['../class_player_board.html#a8482239c3cb137b5f23be867de97d125',1,'PlayerBoard']]]
];
