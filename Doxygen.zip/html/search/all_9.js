var searchData=
[
  ['p_5fname_0',['p_name',['../class_abs_p_name.html#ac6f46fc72e188241fec58ee96d356185',1,'AbsPName']]],
  ['p_5fsocre_1',['p_socre',['../class_abs_p_score.html#aaf41cf91881bfa9461cbe370e94ccd4a',1,'AbsPScore']]],
  ['person_2',['Person',['../class_person.html',1,'Person&lt; TN, TS &gt;'],['../class_person.html#a31da940c7eddb2fa2c118f6cc734d661',1,'Person::Person()']]],
  ['player_3',['Player',['../class_player.html',1,'Player'],['../class_player.html#affe0cc3cb714f6deb4e62f0c0d3f1fd8',1,'Player::Player()'],['../class_player.html#af24e1f7b810e63b5e9cc9ad0dd3f4f2e',1,'Player::Player(AbsPName *name, AbsPScore *score)'],['../class_player.html#adac59c8a4db8e3fe2e65217ca0ed2496',1,'Player::Player(const Player &amp;obj)']]],
  ['player_2ecpp_4',['player.cpp',['../player_8cpp.html',1,'']]],
  ['player_2eh_5',['player.h',['../player_8h.html',1,'']]],
  ['player_2eo_2ed_6',['player.o.d',['../player_8o_8d.html',1,'']]],
  ['player_5fh_7',['PLAYER_H',['../player_8h.html#aa3fab1fddd7bdec7c2d0867fb8aaad64',1,'player.h']]],
  ['playerboard_8',['PlayerBoard',['../class_player_board.html',1,'']]],
  ['playerboard_9',['playerboard',['../class_game.html#a49186eea328cf43088ff4d9547492c85',1,'Game']]],
  ['playerboard_10',['PlayerBoard',['../class_player_board.html#af23b4ccb54f2340e43268d6829e0b69a',1,'PlayerBoard']]],
  ['playgame_11',['playgame',['../class_game.html#a35bbac189f7036e4d8fd38b0639339f7',1,'Game']]],
  ['pname_12',['PName',['../class_p_name.html',1,'']]],
  ['popback_13',['popback',['../template_8h.html#aea16edd876847a54b3b53e9703ccf6f0',1,'template.h']]],
  ['pscore_14',['PScore',['../class_p_score.html',1,'']]],
  ['pushback_15',['pushback',['../template_8h.html#ab7d046b5002de55e09def686054e030a',1,'template.h']]]
];
