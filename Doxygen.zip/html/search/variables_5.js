var searchData=
[
  ['p_5fname_0',['p_name',['../class_abs_p_name.html#ac6f46fc72e188241fec58ee96d356185',1,'AbsPName']]],
  ['p_5fsocre_1',['p_socre',['../class_abs_p_score.html#aaf41cf91881bfa9461cbe370e94ccd4a',1,'AbsPScore']]],
  ['playerboard_2',['playerboard',['../class_game.html#a49186eea328cf43088ff4d9547492c85',1,'Game']]]
];
