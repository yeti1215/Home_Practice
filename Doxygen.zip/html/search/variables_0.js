var searchData=
[
  ['boardary1_0',['boardAry1',['../class_base_board.html#a63128a9aba81ddc53f52268403875975',1,'BaseBoard']]],
  ['boardary2_1',['boardAry2',['../class_base_board.html#acf7a6638dce50926fc58d20c518a8fd1',1,'BaseBoard']]]
];
