var searchData=
[
  ['resultcheck1_0',['resultCheck1',['../class_game.html#a76a9af71973828b4913f10628b2a87b8',1,'Game']]],
  ['resultcheck2_1',['resultCheck2',['../class_game.html#a148bc722f76cbef464fac38fee319cf3',1,'Game']]],
  ['row_2',['row',['../class_base_board.html#af07c9dd3f398cb159bf299654b6c5a44',1,'BaseBoard']]]
];
