var searchData=
[
  ['score_0',['Score',['../class_person.html#a3ac8ebb5ff20f5605216bfdf02799bcf',1,'Person']]],
  ['selectd_1',['selectD',['../class_player_board.html#a75357b58a0ea8636bf9b6664b348f1d2',1,'PlayerBoard']]],
  ['startc_2',['startC',['../class_player_board.html#a6390e7b0333291a9302617488f2487fc',1,'PlayerBoard']]],
  ['startr_3',['startR',['../class_player_board.html#a8a9062ec7b3f923df510f2f75d779717',1,'PlayerBoard']]]
];
