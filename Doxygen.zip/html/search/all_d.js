var searchData=
[
  ['_7ebaseboard_0',['~BaseBoard',['../class_base_board.html#aa48ad0c4977afb55c0759d4422b9dd7a',1,'BaseBoard']]],
  ['_7eplayer_1',['~Player',['../class_player.html#a749d2c00e1fe0f5c2746f7505a58c062',1,'Player']]]
];
