var searchData=
[
  ['abspname_0',['AbsPName',['../class_abs_p_name.html',1,'']]],
  ['abspscore_1',['AbsPScore',['../class_abs_p_score.html',1,'']]]
];
