var searchData=
[
  ['setboard1_0',['setBoard1',['../class_player_board.html#a69371cab6188a2ebcef63ace8704e283',1,'PlayerBoard']]],
  ['setboard2_1',['setBoard2',['../class_player_board.html#ac764459091146a82b2808dcb4f0bb305',1,'PlayerBoard']]],
  ['setname_2',['setName',['../class_abs_p_name.html#aee11f981b9284cc3bbd907d5aa006950',1,'AbsPName::setName()'],['../class_p_name.html#a87255f832be606634fdd30ea9d854238',1,'PName::setName()']]],
  ['showperson_3',['showPerson',['../class_person.html#a44ddc57bb6eb0763f08be22ef825016b',1,'Person']]],
  ['showvector_4',['showVector',['../template_8h.html#a407220ba3aa8240537e3280e734a87b1',1,'template.h']]],
  ['submarinecheck1_5',['Submarinecheck1',['../class_game.html#a3e52b41111cb2496c82b8c0c883a43a5',1,'Game']]],
  ['submarinecheck2_6',['Submarinecheck2',['../class_game.html#ae93eafb59a9f969e71828051233ffcf5',1,'Game']]]
];
