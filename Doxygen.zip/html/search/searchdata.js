var indexSectionsWithContent =
{
  0: ".abcdgmnoprst~",
  1: "abgop",
  2: ".bcgmpt",
  3: "bcdgmoprs~",
  4: "bcdgnprs",
  5: "go",
  6: "bgpt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends",
  6: "Macros"
};

