var class_abs_p_name =
[
    [ "setName", "class_abs_p_name.html#aee11f981b9284cc3bbd907d5aa006950", null ],
    [ "p_name", "class_abs_p_name.html#ac6f46fc72e188241fec58ee96d356185", null ]
];