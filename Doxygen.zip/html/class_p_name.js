var class_p_name =
[
    [ "getName", "class_p_name.html#a0506664ec04cad3ebf957fd2db492b56", null ],
    [ "setName", "class_p_name.html#a87255f832be606634fdd30ea9d854238", null ]
];