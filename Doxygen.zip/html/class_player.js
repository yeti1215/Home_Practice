var class_player =
[
    [ "Player", "class_player.html#affe0cc3cb714f6deb4e62f0c0d3f1fd8", null ],
    [ "Player", "class_player.html#af24e1f7b810e63b5e9cc9ad0dd3f4f2e", null ],
    [ "Player", "class_player.html#adac59c8a4db8e3fe2e65217ca0ed2496", null ],
    [ "~Player", "class_player.html#a749d2c00e1fe0f5c2746f7505a58c062", null ],
    [ "operator=", "class_player.html#a09293227196fd8cb841a41e95ddd15b1", null ],
    [ "Game::playgame", "class_player.html#a67d8ac4789599d9a6ccde1ecba5ed646", null ],
    [ "operator<<", "class_player.html#a3c8267502d083e97914219d885aaa67f", null ]
];