var player_8cpp =
[
    [ "operator<<", "player_8cpp.html#a3c8267502d083e97914219d885aaa67f", null ]
];